//
var hz = {};

hz.location = (window.location + '').split('/');
hz.basePath = hz.location[0] + '//' + hz.location[2] + '/' + hz.location[3];

// 获取当前日期
hz.getCurDate = function() {
	var now = new Date();
	var SY = now.getFullYear();
	var SM = now.getMonth();
	var SD = now.getDate();
	return SY + "-" + (SM + 1) + "-" + SD;
};

// 获取今天日期
hz.getTodayDate = function() {
	var now = new Date();
	return getFormatDate(now, "yyyy-MM-dd");
};

// 获取今天开始时间
hz.getTodayTime = function() {
	var now = new Date();
	return getFormatDate(now, "yyyy-MM-dd") + " " + "00:00:00";
};

// 获取今天开始时间
hz.getNowTime = function() {
	var now = new Date();
	return getFormatDate(now, "yyyy-MM-dd hh:mm:ss");
};

// 获取前一天日期
hz.getYesterdayDate = function() {
	var now = new Date();
	var yesterday = new Date();
	yesterday.setTime(now.getTime() - 1000 * 60 * 60 * 24);
	return getFormatDate(yesterday, "yyyy-MM-dd");
};

// 获取7天前日期
hz.getPre7Date = function(queryDay) {
	queryDay = queryDay.replace(/-/g, "/");
	var queryDate = new Date(queryDay);
	queryDate.setTime(queryDate.getTime() - 1000 * 60 * 60 * 24 * 7);
	return getFormatDate(queryDate, "yyyy-MM-dd");
};

// 获取30天前日期
hz.getPre30Date = function(queryDay) {
	queryDay = queryDay.replace(/-/g, "/");
	var queryDate = new Date(queryDay);
	queryDate.setTime(queryDate.getTime() - 1000 * 60 * 60 * 24 * 30);
	return getFormatDate(queryDate, "yyyy-MM-dd");
};

// 获取前30天日期
hz.getPre30Day = function(queryDay) {
	queryDay = queryDay.replace(/-/g, "/");
	var queryDate = new Date(queryDay);
	var array = new Array();
	for (var i = 30; i >= 0; i--) {
		var tmp = new Date();
		tmp.setTime(queryDate.getTime() - 1000 * 60 * 60 * 24 * i);
		var day = getFormatDate(tmp, "yyyy-MM-dd");
		array[array.length] = day;
	}
	return array;
};
//
hz.getPre12Month = function() {
	var now = new Date();
	var queryDate = new Date();
	queryDate.setTime(now.getTime() - 1000 * 60 * 60 * 24);
	queryDate.setMonth(queryDate.getMonth() - 12);
	return getFormatDate(queryDate, "yyyy-MM");
}

hz.getYesterdayMonth = function() {
	var now = new Date();
	var yesterday = new Date();
	yesterday.setTime(now.getTime() - 1000 * 60 * 60 * 24);
	return getFormatDate(yesterday, "yyyy-MM");
}

hz.getLastMonth = function() {
	var now = new Date();
	var lastMonthNow = addMonth(now, -1);;
	return getFormatDate(lastMonthNow, "yyyy-MM");
}

// 获取日期区间
hz.getRegionDay = function(startDay, endDay) {
	startDay = startDay.replace(/-/g, "/");
	var startDate = new Date(startDay);
	endDay = endDay.replace(/-/g, "/");
	var endDate = new Date(endDay);
	var array = new Array();
	var i = 0;
	while (true) {
		var tmp = new Date();
		tmp.setTime(startDate.getTime() + 1000 * 60 * 60 * 24 * i);
		if (tmp.getTime() > endDate.getTime()) {
			break;
		}
		var day = getFormatDate(tmp, "yyyy-MM-dd");
		array[array.length] = day;
		i++;
	}
	return array;
};

// 获取月区间
hz.getRegionMonth = function(startDay, endDay) {
	var startDate = formatMonthDay(startDay);
	var endDate = formatMonthDay(endDay);
	var array = new Array();
	var i = 0;
	while (true) {
		var tmp = addMonth(startDate, i);
		if (tmp.getTime() > endDate.getTime()) {
			break;
		}
		var month = getFormatDate(tmp, "yyyyMM");
		array[array.length] = month;
		i++;
	}
	return array;
};

function dateToDate(date) {
	var sDate = new Date();
	if (typeof date == 'object' && typeof new Date().getMonth == "function") {
		sDate = date;
	} else if (typeof date == "string") {
		var arr = date.split('-')
		if (arr.length == 3) {
			sDate = new Date(arr[0] + '-' + arr[1] + '-' + arr[2]);
		}
	}

	return sDate;
}

function addMonth(date, num) {
	num = parseInt(num);
	var sDate = dateToDate(date);

	var sYear = sDate.getFullYear();
	var sMonth = sDate.getMonth() + 1;
	var sDay = sDate.getDate();

	var eYear = sYear;
	var eMonth = sMonth + num;
	var eDay = sDay;
	while (eMonth > 12) {
		eYear++;
		eMonth -= 12;
	}

	var eDate = new Date(eYear, eMonth - 1, eDay);

	while (eDate.getMonth() != eMonth - 1) {
		eDay--;
		eDate = new Date(eYear, eMonth - 1, eDay);
	}

	return eDate;
}

/**
 * 格式化日期
 * 
 * @param value
 * @returns
 */
function formatDate(value) {
	var dateReg = /^([0-9]{4})([0-1]?[0-9]{1})([0-3]?[0-9]{1})/;
	var arr = dateReg.exec(value);
	if (arr && arr[0]) {
		return arr[1] + "-" + arr[2] + "-" + arr[3];
	}
	return value;
}

/**
 * 格式化月份
 * 
 * @param value
 * @returns
 */
function formatMonthDay(value) {
	var dateReg = /^([0-9]{4})([0-1]?[0-9]{1})$/;
	var arr = dateReg.exec(value);
	if (arr && arr[0]) {
		return new Date(arr[1] + "-" + arr[2] + "-" + "01");
	}
	return new Date();
}

function formatMonth(value) {
	var dateReg = /^([0-9]{4})([0-1]?[0-9]{1})$/;
	var arr = dateReg.exec(value);
	if (arr && arr[0]) {
		return arr[1] + "-" + arr[2];
	}
	return value;
}

/**
 * 格式化月份
 * 
 * @param value
 * @returns
 */
function formatMonths(value) {
	var dateReg = /^([0-9]{4})([0-1]?[0-9]{1})-([0-9]{4})([0-1]?[0-9]{1})$/;
	var dateReg2 = /^([0-9]{4})([0-1]?[0-9]{1})$/;
	var arr = dateReg.exec(value);
	if (arr && arr[0]) {
		return arr[1] + "年" + arr[2] + "月" + "-" + arr[3] + "年" + arr[4] + "月";
	}
	var arr2 = dateReg2.exec(value);
	if (arr2 && arr2[0]) {
		return arr2[1] + "年" + arr2[2] + "月";
	}
	return value;
}

/**
 * 转化百分比
 * 
 * @param data
 * @returns {String}
 */
function toPercent(data) {
	var strData = parseFloat(data) * 10000;
	strData = Math.round(strData);
	strData /= 100.00;
	return strData.toString() + "%";
}

/**
 * 转换为秒
 * 
 * @param data
 * @returns
 */
function toSecond(data) {
	return (data / 1000).toFixed(2);
}

/**
 * 
 * @param name
 * @returns
 */
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) {
		return unescape(r[2]);
	}
	return null;
}
/**
 * 
 * @param f
 * @param digit
 * @returns {Number}
 */
Math.formatFloat = function(f, digit) {
	var m = Math.pow(10, digit);
	return parseInt(f * m, 10) / m;
}
