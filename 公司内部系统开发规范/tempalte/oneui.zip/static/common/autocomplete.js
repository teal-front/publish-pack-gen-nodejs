function seekPosition(obj, dire) {
    if (obj.getBoundingClientRect && !document.all) {
        var doc = document.documentElement;
        switch (dire) {
        case 0:
            return obj.getBoundingClientRect().top + doc.scrollTop;
        case 1:
            return obj.getBoundingClientRect().right + doc.scrollLeft;
        case 2:
            return obj.getBoundingClientRect().bottom + doc.scrollTop;
        case 3:
            return obj.getBoundingClientRect().left + doc.scrollLeft;
        }
    } else {
        if (dire == 1 || dire == 3) {
            var position = obj.offsetLeft;
        } else {
            var position = obj.offsetTop;
        }
        if (arguments[arguments.length - 1] != 0) {
            if (dire == 1) {
            	position += obj.offsetWidth;
            } else if (dire == 2) {
            	position += obj.offsetHeight;
            }
        }
        if (obj.offsetParent != null) {
        	position += seekPosition(obj.offsetParent, dire, 0);
        }
        return position;
    }
}
function autoTips(varName, max) {
    this.varName = varName;
    this.max = max;
}
autoTips.prototype = {
    target: Object,
    tipsList: Object,
    listeners: null,
    selIndex: 0,
    data: [],
    redata: [],
    create: function(targetObj) {
    	var _this = this;
        var ulObj = document.createElement('ul');
        ulObj.style.display = 'none';
        targetObj.parentNode.insertBefore(ulObj, targetObj);
        _this.tipsList = ulObj;
        targetObj.onkeydown = targetObj.onclick = function(e) {
            _this.listen(this, e);
        };
        targetObj.onblur = function() {
            setTimeout(function() {
                _this.clear();
            },
            100);
        };
    },
    complete: function() {},
    select: function() {
        var _this = this;
        if (_this.redata.length > 0) {
            _this.target.value = _this.redata[_this.selIndex].replace(/\*/g, '*').replace(/\|/g, '|');
            _this.clear();
        }
        _this.complete();
    },
    listen: function(obj) {
        var _this = this;
        _this.target = obj;
        var e = arguments[arguments.length - 1];
        var ev = window.event || e;
        switch (ev.keyCode) {
        case 9:
            //TAB 
            return;
        case 13:
            //ENTER 
            _this.target.blur();
            _this.select();
            return;
        case 38:
            //UP 
            _this.selIndex = _this.selIndex > 0 ? _this.selIndex - 1 : _this.redata.length - 1;
            break;
        case 40:
            //DOWN 
            _this.selIndex = _this.selIndex < _this.redata.length - 1 ? _this.selIndex + 1 : 0;
            break;
        default:
            _this.selIndex = 0;
        }
        if (_this.listeners) {
            clearInterval(_this.listeners);
        }
        _this.listeners = setInterval(function() {
            _this.get();
        },
        10);
    },
    get: function() {
        var _this = this;
        if (_this.target.value == '') {
            _this.clear();
            return;
        }
        if (_this.listeners) {
            clearInterval(_this.listeners);
        };
        _this.redata = [];
        var result = '';
        for (var i = 0; i < _this.data.length; i++) {
            if (_this.data[i].toLowerCase().indexOf(_this.target.value.toLowerCase()) >= 0) {
                _this.redata.push(_this.data[i]);
                if (_this.redata.length == _this.max) {
                    break;
                }
            }
        }
        var regPattern = _this.target.value.replace(/\*/g, '*');
        regPattern = regPattern.replace(/\|/g, '|');
        regPattern = regPattern.replace(/\+/g, '\\+');
        regPattern = regPattern.replace(/\./g, '\\.');
        regPattern = regPattern.replace(/\?/g, '\\?');
        regPattern = regPattern.replace(/\^/g, '\\^');
        regPattern = regPattern.replace(/\$/g, '\\$');
        regPattern = regPattern.replace(/\(/g, '\\(');
        regPattern = regPattern.replace(/\)/g, '\\)');
        regPattern = regPattern.replace(/\[/g, '\\[');
        regPattern = regPattern.replace(/\]/g, '\\]');
        regPattern = regPattern.replace(/\\/g, '\\\\');
        var regExp = new RegExp(regPattern, 'i');
        for (var i = 0; i < _this.redata.length; i++) {
            if (_this.target.value.indexOf('*') >= 0) {
                _this.redata[i] = _this.redata[i].replace(/\*/g, '*');
            }
            if (_this.target.value.indexOf('|') >= 0) {
                _this.redata[i] = _this.redata[i].replace(/\|/g, '|');
            }
            result += '<li style="padding:0 5px;line-height:20px;cursor:default;text-align:left;" onmouseover="' + _this.varName + '.changeOn(this);' + _this.varName + '.selIndex=' + i + ';" onmousedown="' + _this.varName + '.select();">' 
            	+ _this.redata[i].replace(regExp, function(s) {
            											return '<span style="background:#ff9;font-weight:bold;font-style:normal;color:#e60;text-align:left;">' + s + '</span>';
            									  }); + '</li>';
        }
        
        if (result == '') {
            _this.clear();
        } else {
            _this.tipsList.innerHTML = result;
            _this.tipsList.style.cssText = 'display:block;position:absolute;background:#fff;border:#090 solid 1px;margin:-1px 0 0;padding: 5px;list-style:none;font-size:12px;z-index:9999;';
            _this.tipsList.style.top = seekPosition(_this.target, 2) + 'px';
            _this.tipsList.style.left = seekPosition(_this.target, 3) + 'px';
            _this.tipsList.style.width = _this.target.offsetWidth + 'px';
        }
        var liObjs = _this.tipsList.getElementsByTagName('li');
        if (liObjs.length > 0) {
        	liObjs[_this.selIndex].style.cssText = 'background:#36c;padding:0 5px;line-height:20px;cursor:default;color:#fff;text-align:left;';
        }
    },
    changeOn: function(obj) {
        var liObjs = this.tipsList.getElementsByTagName('li');
        for (var i = 0; i < liObjs.length; i++) {
        	liObjs[i].style.cssText = 'padding:0 5px;line-height:20px;cursor:default;text-align:left;';
        }
        obj.style.cssText = 'background:#36c;padding:0 5px;line-height:20px;cursor:default;color:#fff;text-align:left;';
    },
    clear: function() {
        var _this = this;
        if (_this.tipsList) {
            _this.tipsList.style.display = 'none';
            _this.redata = [];
            _this.selIndex = 0;
        }
    }
}
