
$(document).ready(function() {
	if (window != top){
		top.location.href = location.href;
		return;
	}
});