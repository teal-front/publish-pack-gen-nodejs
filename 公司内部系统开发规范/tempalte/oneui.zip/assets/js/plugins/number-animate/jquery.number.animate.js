;(function($) {
	//乘法函数  
	function accMul(arg1, arg2) {  
	  var m = 0, s1 = arg1.toString(), s2 = arg2.toString();  
	  try {  
	      m += s1.split(".")[1].length;  
	  }  
	  catch (e) {  
	  }  
	  try {  
	      m += s2.split(".")[1].length;  
	  }  
	  catch (e) {  
	  }  
	  return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);  
	}   

	//给Number类型增加一个mul方法，使用时直接用 .mul 即可完成计算。   
	Number.prototype.mul = function (arg) {  
	  return accMul(arg, this);  
	};   

	//除法函数  
	function accDiv(arg1, arg2) {  
	  var t1 = 0, t2 = 0, r1, r2;  
	  try {  
	      t1 = arg1.toString().split(".")[1].length;  
	  }  
	  catch (e) {  
	  }  
	  try {  
	      t2 = arg2.toString().split(".")[1].length;  
	  }  
	  catch (e) {  
	  }  
	  with (Math) {  
	      r1 = Number(arg1.toString().replace(".", ""));  
	      r2 = Number(arg2.toString().replace(".", ""));  
	      return (r1 / r2) * pow(10, t2 - t1);  
	  }  
	}   
	//给Number类型增加一个div方法，，使用时直接用 .div 即可完成计算。   
	Number.prototype.div = function (arg) {  
	  return accDiv(this, arg);  
	};
	function accAdd(arg1, arg2) {  
	  var r1, r2, m;  
	  try {  
	      r1 = arg1.toString().split(".")[1].length;  
	  }  
	  catch (e) {  
	      r1 = 0;  
	  }  
	  try {  
	      r2 = arg2.toString().split(".")[1].length;  
	  }  
	  catch (e) {  
	      r2 = 0;  
	  }  
	  m = Math.pow(10, Math.max(r1, r2));  
	  return (arg1.mul(m) + arg2.mul(m)).div(m);  
	}   

	//给Number类型增加一个add方法，，使用时直接用 .add 即可完成计算。   
	Number.prototype.add = function (arg) {  
	  return accAdd(arg, this);  
	};  


	//减法函数  
	function Subtr(arg1, arg2) {  
	  var r1, r2, m, n;  
	  try {  
	      r1 = arg1.toString().split(".")[1].length;  
	  }  
	  catch (e) {  
	      r1 = 0;  
	  }  
	  try {  
	      r2 = arg2.toString().split(".")[1].length;  
	  }  
	  catch (e) {  
	      r2 = 0;  
	  }  
	  m = Math.pow(10, Math.max(r1, r2));  
	   //last modify by deeka  
	   //动态控制精度长度  
	  n = (r1 >= r2) ? r1 : r2;  
	  return parseFloat(((arg1 * m - arg2 * m) / m).toFixed(n));  
	}  

	//给Number类型增加一个add方法，，使用时直接用 .sub 即可完成计算。   
	Number.prototype.sub = function (arg) {  
	  return Subtr(this, arg);  
	};
	
	var numbers = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];

	var inits = new HashMap();
	
	// 显示数字
	$.fn.extend({
		showFloatNumber:function(number, unit, size){
			var $this = $(this);
			
			var numberClass = "number";
			var signClass = "sign";
			var unitClass = "unit";
			if(size != undefined){
				numberClass = "number-" + size;
				signClass = "sign-" + size;
				unitClass = "unit-" + size;
			}
			var init = inits.get($this.attr("id"));
			if(init != 1){
				$this.append("<div class='h-k-k " + numberClass + "'></div>");
				$this.append("<div class='t-k-k " + numberClass + "'></div>");
				$this.append("<div class='k-k " + numberClass + "'></div>");
				$this.append("<div class='k-k-sign comma " + signClass + "'>,</div>");
				$this.append("<div class='h-k " + numberClass + "'></div>");
				$this.append("<div class='t-k " + numberClass + "'></div>");
				$this.append("<div class='k " + numberClass + "'></div>");
				$this.append("<div class='k-sign comma " + signClass + "'>,</div>");
				$this.append("<div class='h " + numberClass + "'></div>");
				$this.append("<div class='t " + numberClass + "'></div>");
				$this.append("<div class='single " + numberClass + "'></div>");
				$this.append("<div class='dot-sign dot " + signClass + "'>.</div>");
				$this.append("<div class='t-d " + numberClass + "'></div>");
				$this.append("<div class='h-d " + numberClass + "'></div>");
				if(unit != undefined){
					$this.append("<div class='" + unitClass + "'>" + unit + "</div>");
				}
				init = 1;
				inits.put($this.attr("id"), init);
			}
			
			var $hkk = $this.find(".h-k-k"); 
			var $tkk = $this.find(".t-k-k"); 
			var $kk = $this.find(".k-k"); 
			var $hk = $this.find(".h-k"); 
			var $tk = $this.find(".t-k"); 
			var $k = $this.find(".k"); 
			var $h = $this.find(".h");
			var $t = $this.find(".t");
			var $single = $this.find(".single");
			var $td = $this.find(".t-d");
			var $hd = $this.find(".h-d");
			var $kkcomma = $this.find(".k-k-sign");
			var $kcomma = $this.find(".k-sign");
			var $dot = $this.find("dot-sign");
				
			var data = {
			  targetClass: {
				"hkk": $hkk,
				"tkk": $tkk,
				"kk": $kk,
				"hk": $hk,
				"tk": $tk,
				"k": $k,
				"h": $h,
				"t": $t,
				"single": $single,
				"td": $td,
				"hd": $hd
			  },
			  zero: {
				hkk: 0,
				tkk: 0,
				kk: 0,
				hk: 0,
				tk: 0,
				k: 0,
				h: 0,
				t: 0,
				single: 0,
				td: 0,
				hd: 0
			  },
			  numbersTmp: ""
			};
		  
			for(var i = 0; i < 10; i ++) {
				data.numbersTmp += "<div class='" + numbers[i] + "'>" + i + "</div>";
			}
			
			$this.find("." + numberClass).append("<div class='numbers-view'>" + data.numbersTmp + "</div>");
			
			
			function numberToObj(number){
				if(number == 0) {
					return data.zero;
				}
				var obj = {};
				obj.hd = parseInt((number.mul(100)) % 10);
				obj.td = parseInt((number.mul(10)) % 10);
				obj.single = parseInt(number % 10);
				obj.t = parseInt((number.div(10)) % 10);
				obj.h = parseInt((number.div(100)) % 10);
				obj.k = parseInt((number.div(1000)) % 10);
				obj.tk = parseInt((number.div(10000)) % 10);
				obj.hk = parseInt((number.div(100000)) % 10);
				obj.kk = parseInt((number.div(1000000)) % 10);
				obj.tkk = parseInt((number.div(10000000)) % 10);
				obj.hkk = parseInt((number.div(100000000)) % 10);
				return obj;
			}

			function objToNumber(obj) {
				return obj.hkk.mul(100000000).add(obj.tkk.mul(10000000))
					.add(obj.kk.mul(1000000)).add(obj.hk.mul(100000))
					.add(obj.tk.mul(10000)).add(obj.k.mul(1000))
					.add(obj.h.mul(100)).add(obj.t.mul(10))
					.add(obj.single).add(obj.td.div(10)).add(obj.hd.div(100));
			}
					
			var obj = numberToObj(number);
			if(number >= 0 && number < 1000){
				$kcomma.hide();
				$kkcomma.hide();
			} else if(number >= 1000 && number < 1000000){
				$kcomma.show();
				$kkcomma.hide();
			} else {
				$kcomma.show();
				$kkcomma.show();
			}
			if(number < 10){
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				$k.hide();
				$h.hide();
				$t.hide();
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
				delete obj.k;
				delete obj.h;
				delete obj.t;
			} else if(number >= 10 && number < 100){
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				$k.hide();
				$h.hide();
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
				delete obj.k;
				delete obj.h;
			} else if(number >= 100 && number < 1000){
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				$k.hide();
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
				delete obj.k;
			} else if(number >= 1000 && number < 10000){
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
			} else if(number >= 10000 && number < 100000){
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
			} else if(number >= 100000 && number < 1000000){
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
			} else if(number >= 1000000 && number < 10000000){
				$hkk.hide();
				$tkk.hide();
				delete obj.hkk;
				delete obj.tkk;
			} else if(number >= 10000000 && number < 100000000){
				$hkk.hide();
				delete obj.hkk;
			}
			console.log(obj);
			$.each(obj, function(key, value){
				data.targetClass[key].scrollToNumber(value, key, data.numbersTmp);
			});
		},
		
		showIntNumber:function(number, unit, size){
			var $this = $(this);
			
			var numberClass = "number";
			var signClass = "sign";
			var unitClass = "unit";
			if(size != undefined){
				numberClass = "number-" + size;
				signClass = "sign-" + size;
				unitClass = "unit-" + size;
			}
			var init = inits.get($this.attr("id"));
			if(init != 1){
				$this.append("<div class='t-k-k-k " + numberClass + "'></div>");
				$this.append("<div class='k-k-k " + numberClass + "'></div>");
				$this.append("<div class='k-k-k-sign comma " + signClass + "'>,</div>");
				$this.append("<div class='h-k-k " + numberClass + "'></div>");
				$this.append("<div class='t-k-k " + numberClass + "'></div>");
				$this.append("<div class='k-k " + numberClass + "'></div>");
				$this.append("<div class='k-k-sign comma " + signClass + "'>,</div>");
				$this.append("<div class='h-k " + numberClass + "'></div>");
				$this.append("<div class='t-k " + numberClass + "'></div>");
				$this.append("<div class='k " + numberClass + "'></div>");
				$this.append("<div class='k-sign comma " + signClass + "'>,</div>");
				$this.append("<div class='h " + numberClass + "'></div>");
				$this.append("<div class='t " + numberClass + "'></div>");
				$this.append("<div class='single " + numberClass + "'></div>");
				if(unit != undefined){
					$this.append("<div class='" + unitClass + "'>" + unit + "</div>");
				}
				init = 1;
				inits.put($this.attr("id"), init);
			}
			
			var $tkkk = $this.find(".t-k-k-k"); 
			var $kkk = $this.find(".k-k-k"); 
			var $hkk = $this.find(".h-k-k"); 
			var $tkk = $this.find(".t-k-k"); 
			var $kk = $this.find(".k-k"); 
			var $hk = $this.find(".h-k"); 
			var $tk = $this.find(".t-k"); 
			var $k = $this.find(".k"); 
			var $h = $this.find(".h");
			var $t = $this.find(".t");
			var $single = $this.find(".single");
			var $kkkcomma = $this.find(".k-k-k-sign");
			var $kkcomma = $this.find(".k-k-sign");
			var $kcomma = $this.find(".k-sign");
				
			var data = {
			  targetClass: {
				"tkkk": $tkkk,
				"kkk": $kkk,
				"hkk": $hkk,
				"tkk": $tkk,
				"kk": $kk,
				"hk": $hk,
				"tk": $tk,
				"k": $k,
				"h": $h,
				"t": $t,
				"single": $single
			  },
			  zero: {
				tkkk: 0,
				kkk: 0,
				hkk: 0,
				tkk: 0,
				kk: 0,
				hk: 0,
				tk: 0,
				k: 0,
				h: 0,
				t: 0,
				single: 0
			  },
			  numbersTmp: ""
			};
		  
			for(var i = 0; i < 10; i ++) {
				data.numbersTmp += "<div class='" + numbers[i] + "'>" + i + "</div>";
			}
		  
			$this.find("." + numberClass).append("<div class='numbers-view'>" + data.numbersTmp + "</div>");
			
			
			function numberToObj(number){
				if(number == 0) {
					return data.zero;
				}
				var obj = {};
				obj.single = parseInt(number % 10);
				obj.t = parseInt((number.div(10)) % 10);
				obj.h = parseInt((number.div(100)) % 10);
				obj.k = parseInt((number.div(1000)) % 10);
				obj.tk = parseInt((number.div(10000)) % 10);
				obj.hk = parseInt((number.div(100000)) % 10);
				obj.kk = parseInt((number.div(1000000)) % 10);
				obj.tkk = parseInt((number.div(10000000)) % 10);
				obj.hkk = parseInt((number.div(100000000)) % 10);
				obj.kkk = parseInt((number.div(1000000000)) % 10);
				obj.tkkk = parseInt((number.div(10000000000)) % 10);
				return obj;
			}

			function objToNumber(obj) {
				return obj.tkkk.mul(10000000000).add(obj.kkk.mul(1000000000))
					.add(obj.hkk.mul(100000000)).add(obj.tkk.mul(10000000))
					.add(obj.kk.mul(1000000)).add(obj.hk.mul(100000))
					.add(obj.tk.mul(10000)).add(obj.k.mul(1000))
					.add(obj.h.mul(100)).add(obj.t.mul(10))
					.add(obj.single);
			}
					
			var obj = numberToObj(number);
			if(number >= 0 && number < 1000){
				$kcomma.hide();
				$kkcomma.hide();
				$kkkcomma.hide();
			} else if(number >= 1000 && number < 1000000){
				$kcomma.show();
				$kkcomma.hide();
				$kkkcomma.hide();
			} else if(number >= 1000000 && number < 1000000000){
				$kcomma.show();
				$kkcomma.show();
				$kkkcomma.hide();
			} else {
				$kcomma.show();
				$kkcomma.show();
				$kkkcomma.show();
			}
			if(number < 10){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				$k.hide();
				$h.hide();
				$t.hide();
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
				delete obj.k;
				delete obj.h;
				delete obj.t;
			} else if(number >= 10 && number < 100){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				$k.hide();
				$h.hide();
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
				delete obj.k;
				delete obj.h;
			} else if(number >= 100 && number < 1000){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				$k.hide();
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
				delete obj.k;
			} else if(number >= 1000 && number < 10000){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				$tk.hide(); 
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
				delete obj.tk;
			} else if(number >= 10000 && number < 100000){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				$hk.hide();
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
				delete obj.hk; 
			} else if(number >= 100000 && number < 1000000){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				$tkk.hide();
				$kk.hide();
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
				delete obj.tkk;
				delete obj.kk;
			} else if(number >= 1000000 && number < 10000000){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				$tkk.hide();
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
				delete obj.tkk;
			} else if(number >= 10000000 && number < 100000000){
				$tkkk.hide();
				$kkk.hide();
				$hkk.hide();
				delete obj.tkkk;
				delete obj.kkk;
				delete obj.hkk;
			} else if(number >= 100000000 && number < 1000000000){
				$tkkk.hide();
				$kkk.hide();
				delete obj.tkkk;
				delete obj.kkk;
			} else if(number >= 1000000000 && number < 10000000000){
				$tkkk.hide();
				delete obj.tkkk;
			}
			$.each(obj, function(key, value){
				data.targetClass[key].scrollToNumber(value, key, data.numbersTmp);
			});
		},
		
		scrollToNumber: function(num, pos, numbersTmp){
			var $this = $(this);
			$this.show();
			var target = numbers[num];

			$this.find(".numbers-view").stop(true, true);

			var top = num * $this.find(".zero").height();
			console.log($this.html());
			var currentTop = -parseFloat($this.find(".numbers-view").css("marginTop").split("px")[0]);
			
			if(top == currentTop) {
				return;
			} else if(currentTop < top) {
				$this.find(".numbers-view").animate({marginTop: -top}, 1500, "swing");
			} else {
				$this.find(".numbers-view").append($(numbersTmp).addClass("temp"));
				top = $this.find("." + target + ".temp").offset().top - $this.find(".numbers-view").offset().top;
			  
				$this.find(".numbers-view").animate({marginTop: -top}, 1500, "swing", function(){
					if($this.find(".zero").size() > 1) {
						var top = $this.find("." + target + ":not(.temp)").first().offset().top - $this.find(".numbers-view").offset().top;
						$this.find(".numbers-view").css({marginTop: -top});
						$this.find(".numbers-view .temp").remove();
					}
				});
			}
		}
	});
	
})(jQuery);