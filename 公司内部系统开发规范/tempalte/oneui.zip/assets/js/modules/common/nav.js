
// 菜单
var _menus = {
	"menus" : [ {
		"menuid" : "1",
		"icon" : "fa-bar-chart-o",
		"menuname" : "网站流量统计",
		"menus" : [ {
			"menuid" : "111",
			"menuname" : "流量趋势总体",
			"icon" : "icon-nav",
			"url" : hz.basePath +"/web/trend/overview"
		}, {
			"menuid" : "112",
			"menuname" : "页面浏览统计",
			"icon" : "icon-nav",
			"url" : hz.basePath + "/web/page/pagedetail"
		}]
	},{
		"menuid" : "2",
		"icon" : "fa-cutlery",
		"menuname" : "订单交易数据",
		"menus" : [ {
			"menuid" : "211",
			"menuname" : "险种交易统计",
			"icon" : "icon-nav",
			"url" : hz.basePath + "/order/trans/category"
		}]
	},{
		"menuid" : "3",
		"icon" : "fa-cutlery",
		"menuname" : "用户数据",
		"menus" : [ {
			"menuid" : "311",
			"menuname" : "用户详细查询",
			"icon" : "icon-nav",
			"url" : hz.basePath + "/user/attribute/list"
		}]
	}]
};

$(document).ready(function(){
    // 加载菜单
	loadMenus();
	// 
	showLogout();
	//
	showBussinessSys();
	//
	closeBussinessSys();
	
	// 加载业务系统
	loadSysMenus();
	
	// 退出登录
	loginOut();
	
});

function loadMenus(){
	/*
	$.ajax({
		url : hz.basePath + "/getMenus?r=" + Math.random(),
		type : 'post',
		dataType : 'json',
		success : function(data) {
			var key = parseInt(Math.random() * 10000).toString();
			var _menus_ = {};
			_menus_.menus = [];
			$.each(data, function(index, m) {
				var menu = {};
				menu.menuid = String(m.menuid);
				menu.icon = m.icon;
				if(m.icon == null){
					menu.icon = "fa-bar-chart-o";
				}
				menu.menuname = m.menuname;
				var title = m.menuname, unicode;
				if(m.url != null && m.url != ""){
					if (m.url.indexOf('http') == 0) {
						menu.url = m.url + "#" + key + "|" + title;
					} else {
						menu.url = hz.basePath + m.url;
					}
				}
				if (m.menus && m.menus.length > 0) {
					var submenus = [];
					$.each(m.menus, function(j, o) {
						var submenu = {};
						submenu.menuid = String(o.menuid);
						submenu.icon = o.icon;
						if(o.icon == null){
							submenu.icon = "icon-nav";
						}
						submenu.menuname = o.menuname;
						var subtitle = o.menuname, unicode;
						if(o.url != null && o.url != ""){
							if (o.url.indexOf('http') == 0) {
								submenu.url = o.url + "#" + key + "|" + subtitle;
							} else {
								submenu.url = hz.basePath + o.url;
							}
						}
						submenus.push(submenu);
					});
					menu.menus = submenus;
				}
				_menus_.menus.push(menu);
			});
			initLeftMenu(_menus_);
			// 加载oneui.js
			loadOneUiJs();
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(errorThrown);
		}
	});
	*/
	initLeftMenu(_menus);
	// 加载oneui.js
	loadOneUiJs();
}

function loadOneUiJs(){
	var bp = document.createElement('script');
    bp.src = "../../assets/js/oneui.min.js";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
}

function showLogout(){
	$("#loginUser").click(function(){
		if($("#logout-menu").is(":hidden")){
			$("#logout-menu").show();
		} else {
			$("#logout-menu").hide();
		}
	});
	
}

function showBussinessSys(){
	$("#redirect").click(function(){
		if($("#business-sys").is(":hidden")){
			$("#business-sys").show();
		} else {
			$("#business-sys").hide();
		}
	});
}

function closeBussinessSys(){
	$("#close-busssiness").click(function(){
		$("#business-sys").hide();
	});
}

function loadSysMenus(){
	$.ajax({
		url : hz.basePath + "/getSysMenus?r=" + Math.random(),
		type : 'post',
		dataType : 'json',
		success : function(data) {
			$.each(data, function(index, m) {
				var sysName = m.sysName;
				var sysCode = m.sysCode;
				var sysUrl = m.sysUrl;
				$("#business-sys").append("<li><div class='font-w600' style='width:300px;padding-left:15px;padding-top:5px;'><i class='fa fa-circle text-success' style='margin-right:15px;'></i><a href='" + sysUrl + "' target='_blank'>" + sysName + "</a></div><div><small class='text-muted'></small></div></li>");
			});
		}
	});
}
//
function loginOut(){
	$("#loginOut").click(function() {
		var loginOutUrl = hz.basePath + "/logout?v=" + Math.random();
		$.ajax({
			url : loginOutUrl,
			type : 'post',
			dataType : 'json',
			success : function() {
				if (getCookie("hzins.com") != null
						&& getCookie("hzins.com") != "") {
					var date = new Date();
					date.setDate(date.getDate() - 1);
					document.cookie = "hzins.com="
							+ escape(getCookie("hzins.com"))
							+ ";expires=" + date
							+ ";path=/;domain=hzins.com";
				}
				top.location = hz.basePath + "/";
			}, 
			error: function (XMLHttpRequest, textStatus, errorThrown) {
			    console.log("推迟登录出错");
			    top.location = hz.basePath + "/";
			}
		});
	});
}

//初始化左侧
function initLeftMenu(menus) {
	$.each(menus.menus, function(i, n) {
		if(n.icon == null){
			n.icon = "fa-cutlery";
		}
		var menulist = '';
		menulist += '<li>';
		menulist += '<a class="nav-submenu" data-toggle="nav-submenu" href="javascript:;"><i class="fa ' + n.icon + '"></i><span class="sidebar-mini-hide">'
			+ n.menuname + '</span></a>';
		if (n.menus && n.menus.length > 0) {
			menulist += '<ul>';
			$.each(n.menus, function(j, o) {
				menulist += '<li><a ref="' + o.menuid
					+ '" href="javascript:;" rel="' + o.url
					+ '" class="J_menuTab">' + o.menuname
					+ '</a></li>';
				if (o.child && o.child.length > 0) {
					menulist += '<ul>';
					$.each(o.child, function(k, p) {
						menulist += '<li><a ref="' + p.menuid
								+ '" href="javascript:;" rel="' + p.url
								+ '" class="J_menuTab">' + p.menuname
								+ '</a></li>'
					});
				}
			});
			menulist += '</ul>';
		}
		menulist += '</li>';
		$("#left-nav-container").append(menulist);
	});
	
	
	$(".J_menuTab").click(function() {
		var tabTitle = $(this).text();
		var url = $(this).attr("rel");
		var menuId = $(this).attr("ref");
		var exists = false;
		$("#page-tabs-content a").attr("class", "J_menuTab");
		$(".J_iframe").css("display", "none");
		$("#page-tabs-content a").each(function(){
			if($(this).text() == tabTitle){
				$(this).attr("class", "J_menuTab active");
				$("#iframe" + menuId).css("display", "block");
				exists = true;
			}
		});
		if(!exists){
			var newTab = '<a ref="' + menuId + '" rel="' + url + '" href="javascript:;" class="J_menuTab active" data-id="welcome">' + tabTitle + '<i class="fa fa-times-circle" onclick="removeMenuTab();"></i></a>';
			$("#page-tabs-content").append(newTab);
			var newIframe = '<iframe class="J_iframe" name="iframe' + menuId + '" id="iframe' + menuId + '" width="100%" height="100%" src="' + url + '" frameborder="0" data-id="menuId_' + menuId + '" seamless></iframe>';
			$("#content-main").append(newIframe);
		}
	}).hover(function() {
		$(this).parent().addClass("hover");
	}, function() {
		$(this).parent().removeClass("hover");
	});

	$("#page-tabs-content").click(function(e){
		var obj = e ? e.target : event.srcElement;
    	if (obj.tagName == "A"){
    		$("#page-tabs-content a").attr("class", "J_menuTab");
    		$(obj).attr("class", "J_menuTab active");
    		var menuId = $(obj).attr("ref");
    		$(".J_iframe").css("display", "none");
    		$("#iframe" + menuId).css("display", "block");
    	}
	});
	
	$("#toLeft").click(function(){
		var maxWidth = $("#content-tabs").width();
		var step = maxWidth - 100;
		var marginLeft = parseInt($("#page-tabs-content").css("margin-left"));
		if(marginLeft == 0){
			return;
		}
		marginLeft += step
		$("#page-tabs-content").css("margin-left", marginLeft + "px");
	});
	
	$("#toRight").click(function(){
		var maxWidth = $("#content-tabs").width();
		var step = maxWidth - 100;
		var marginLeft = parseInt($("#page-tabs-content").css("margin-left"));
		var width = $("#page-tabs-content").width();
		var diff = width + marginLeft;
		if(diff <= step) {
			return;
		}
		marginLeft -= step
		$("#page-tabs-content").css("margin-left", marginLeft + "px");
	});
}
//删除按钮
function removeMenuTab(e){
	var obj = e ? e.target : event.srcElement;
	var parentObj = $(obj).parent();
	var menuId = $(parentObj).attr("ref");
	$("#page-tabs-content a").attr("class", "J_menuTab");
	$(".J_iframe").css("display", "none");
	if($(parentObj).next() && $(parentObj).next().length > 0){
		var currentObj = $(parentObj).next()[0];
		$(currentObj).attr("class", "J_menuTab active");
		var nextMenuId = $(currentObj).attr("ref");
		$("#iframe" + nextMenuId).css("display", "block");
	} else {
		var currentObj = $(parentObj).prev()[0];
		$(currentObj).attr("class", "J_menuTab active");
		var prevMenuId = $(currentObj).attr("ref");
		$("#iframe" + prevMenuId).css("display", "block");
	}
	$(parentObj).remove();
	$("#iframe" + menuId).remove();
}

function getCookie(name) {
	var arg = name + "=";
	var alen = arg.length;
	var clen = document.cookie.length;
	var i = 0;
	while (i < clen) {
		var j = i + alen;
		if (document.cookie.substring(i, j) == arg) {
			return getCookieVal(j);
		}
		i = document.cookie.indexOf(" ", i) + 1;
		if (i == 0)
			break;
	}
	return null;
}

function getCookieVal(offset) {
	var endstr = document.cookie.indexOf(";", offset);
	if (endstr == -1) {
		endstr = document.cookie.length;
	}
	return unescape(document.cookie.substring(offset, endstr));
}
